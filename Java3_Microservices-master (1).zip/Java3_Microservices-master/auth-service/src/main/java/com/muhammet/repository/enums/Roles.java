package com.muhammet.repository.enums;

public enum Roles {
    ROLE_ADMIN, ROLE_USER
}
