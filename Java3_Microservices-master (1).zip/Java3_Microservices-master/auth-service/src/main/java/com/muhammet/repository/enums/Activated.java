package com.muhammet.repository.enums;

public enum Activated {
    ACTIVE, INACTIVE, DELETED, BANNED, PENDING
}
